# SOC Multi-Agent PoC - AD / Endpoint / Network / Web

Prototype thực nghiệm cho bài toán SOC Multi-Agent:

- 4 Agent chuyên biệt: AD, Endpoint, Network, Web.
- Một Ollama LLM dùng chung.
- RAG local từ Markdown.
- Correlation Agent dùng LLM để tổng hợp kết quả của 4 Agent.
- JSON output thống nhất.
- Mock mode để test pipeline mà không gọi LLM.

## 1. Kiến trúc

```text
                         RAW JSONL
                             |
                           Router
                             |
          +------------------+------------------+
          |                  |                  |
          v                  v                  v
      ADAgent          EndpointAgent       NetworkAgent
          |                  |                  |
          +------------------+------------------+
                             |
                           WebAgent
                             |
                    Agent JSON Findings
                             |
                             v
                    Correlation Agent
                             |
                     Ollama + RAG
                             |
                             v
                      Final SOC JSON
```

4 Agent không chia sẻ raw log với nhau. Mỗi Agent chỉ phân tích domain của mình. Correlation Agent chỉ nhận output đã chuẩn hóa từ 4 Agent.

## 2. Yêu cầu

Khuyến nghị Kali/Ubuntu VM với Python 3.10+.

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip unrar
```

### Tạo môi trường Python

Không tạo `.venv` trong `/media/sf_*` của VirtualBox Shared Folder.

```bash
cd ~/Desktop/soc_multi_agent_final
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 3. Ollama

Kiểm tra:

```bash
ollama --version
ollama list
curl http://127.0.0.1:11434/api/tags
```

Với VM 4 GB RAM, PoC này dùng mặc định:

```bash
export OLLAMA_MODEL=qwen2.5:1.5b
export OLLAMA_TIMEOUT=600
```

Nếu muốn cố định, tạo `.env` từ `.env.example` hoặc export biến môi trường trước khi chạy.

## 4. Dữ liệu

Đã kèm:

```text
data/network/network_demo.jsonl
data/web/web_demo.jsonl
data/archive/Log.rar
```

Giải nén AD/Endpoint:

```bash
unrar x data/archive/Log.rar data/extracted/
find data/extracted -type f -name "*.jsonl"
```

Sau đó đưa các JSONL AD vào `data/ad/` và Endpoint vào `data/endpoint/`.

Nếu AD/Endpoint chưa có dữ liệu, chương trình vẫn chạy và bỏ qua domain đó.

## 5. Test pipeline không dùng LLM

Luôn làm bước này trước:

```bash
python main.py --mode mock --source network --limit 1
```

Sau đó:

```bash
python main.py --mode mock --source web --limit 1
python main.py --mode mock --source ad --limit 1
python main.py --mode mock --source endpoint --limit 1
```

Cuối cùng:

```bash
python main.py --mode mock --source all --limit 1
```

## 6. Test Ollama + Network Agent

```bash
export OLLAMA_MODEL=qwen2.5:1.5b
export OLLAMA_TIMEOUT=600
python main.py --mode ollama --source network --limit 1
```

Để chạy lại:

```bash
python main.py --mode ollama --source network --limit 2
```

## 7. Test Web Agent

```bash
python main.py --mode ollama --source web --limit 1
```

## 8. Test AD và Endpoint

Sau khi đặt dữ liệu vào đúng thư mục:

```bash
python main.py --mode ollama --source ad --limit 1
python main.py --mode ollama --source endpoint --limit 1
```

## 9. Test toàn bộ Multi-Agent

Khi 4 Agent chạy riêng ổn:

```bash
python main.py --mode ollama --source all --limit 1
```

Luồng lúc này:

```text
AD Agent       --+
Endpoint Agent ---+--> Correlation Agent --> RAG --> Final JSON
Network Agent  ---+
Web Agent      ---+
```

## 10. Output

Các file được ghi vào:

```text
outputs/agent_results.json
outputs/correlation.json
```

Output của mỗi Agent dùng schema thống nhất:

```json
{
  "event_id": "...",
  "agent_routed": "NetworkAgent",
  "verdict": "benign|suspicious|malicious|insufficient_evidence",
  "is_false_positive": false,
  "threat_level": "LOW",
  "confidence_score": 0.88,
  "reasoning_steps": [
    "Evidence-based observation"
  ],
  "analysis_summary": "Short security analysis",
  "recommended_actions": [
    "Defensive next step"
  ]
}
```

## 11. Prompt engineering methodology

Mỗi Agent có prompt riêng theo domain:

- `agents/ad.py`
- `agents/endpoint.py`
- `agents/network.py`
- `agents/web.py`

Các prompt đều yêu cầu:

- chỉ dùng evidence từ log;
- tách evidence khỏi hypothesis;
- không tự bịa dữ liệu;
- không coi RAG là bằng chứng trực tiếp;
- trả JSON theo cùng schema;
- confidence từ 0.0 đến 1.0.

Network Prompt đặc biệt cấm các suy luận sai kiểu:

- same-subnet => lateral movement;
- port 443 => malicious;
- connection state `SF` => malicious;
- một event đơn lẻ => đã xảy ra tấn công.

## 12. Ghi nhận thực nghiệm

Khi tối ưu prompt, chạy cùng một event với Prompt V1 và Prompt V2 rồi lưu output để so sánh:

- verdict;
- threat_level;
- confidence_score;
- evidence quality;
- hallucination / unsupported inference;
- latency.

`llm_client.py` tự in thời gian gọi LLM:

```text
[LLM] model=qwen2.5:1.5b http=200 time=12.34s
```

## 13. Ghi chú về tài nguyên

VM 4 GB RAM phù hợp để kiểm chứng PoC với model nhỏ. Phiên bản đã cấu hình mặc định `qwen2.5:1.5b` và timeout 600 giây để giảm lỗi cold-start trong môi trường VM. 7B có thể quá nặng và gây timeout. Nếu cần benchmark chất lượng model lớn hơn, nên chuyển LLM sang máy mạnh hơn hoặc API/cloud mà không thay đổi kiến trúc Agent.

## 14. An toàn

PoC này chỉ phân tích log, tạo nhận định và recommendation. Không có chức năng tự động exploit, tự động khóa tài khoản hoặc phá hệ thống.
