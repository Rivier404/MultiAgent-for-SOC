from __future__ import annotations

import json
import os
import re
import time
from typing import Any

import requests


class LLMError(RuntimeError):
    pass


class OllamaClient:
    def __init__(
        self,
        url: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
    ) -> None:
        self.url = (url or os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")).rstrip("/")
        self.model = model or os.getenv("OLLAMA_MODEL", "qwen2.5:1.5b")
        self.timeout = timeout or int(os.getenv("OLLAMA_TIMEOUT", "600"))

    def chat_json(self, system: str, user: str) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.1},
        }

        started = time.perf_counter()
        try:
            response = requests.post(
                f"{self.url}/api/chat",
                json=payload,
                timeout=self.timeout,
            )
            elapsed = time.perf_counter() - started
            print(f"[LLM] model={self.model} http={response.status_code} time={elapsed:.2f}s")
            response.raise_for_status()
            body = response.json()
            content = body.get("message", {}).get("content", "")
        except requests.RequestException as exc:
            elapsed = time.perf_counter() - started
            raise LLMError(
                f"Ollama request failed after {elapsed:.2f}s: {exc}"
            ) from exc

        return self._parse_json(content)

    @staticmethod
    def _parse_json(text: str) -> dict[str, Any]:
        text = text.strip()
        try:
            value = json.loads(text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", text, flags=re.DOTALL)
            if not match:
                raise LLMError("LLM returned non-JSON output")
            try:
                value = json.loads(match.group(0))
            except json.JSONDecodeError as exc:
                raise LLMError("LLM JSON could not be parsed") from exc

        if not isinstance(value, dict):
            raise LLMError("LLM response must be a JSON object")
        return value
