from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from agents import ADAgent, EndpointAgent, NetworkAgent, WebAgent, CorrelationAgent

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"


def load_jsonl(path: Path, limit: int) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    if not path.exists():
        return events

    with path.open("r", encoding="utf-8", errors="ignore") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict):
                events.append(obj)
            if len(events) >= limit:
                break
    return events


def discover_files(source: str) -> dict[str, list[Path]]:
    mapping = {
        "ad": sorted((DATA_DIR / "ad").glob("*.jsonl")),
        "endpoint": sorted((DATA_DIR / "endpoint").glob("*.jsonl")),
        "network": sorted((DATA_DIR / "network").glob("*.jsonl")),
        "web": sorted((DATA_DIR / "web").glob("*.jsonl")),
    }
    if source != "all":
        return {source: mapping[source]}
    return mapping


def make_agents(mode: str):
    return {
        "ad": ADAgent(mode=mode),
        "endpoint": EndpointAgent(mode=mode),
        "network": NetworkAgent(mode=mode),
        "web": WebAgent(mode=mode),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="SOC Multi-Agent PoC")
    parser.add_argument("--mode", choices=["mock", "ollama"], default="mock")
    parser.add_argument(
        "--source",
        choices=["ad", "endpoint", "network", "web", "all"],
        default="all",
    )
    parser.add_argument("--limit", type=int, default=1)
    args = parser.parse_args()

    print(f"[config] mode={args.mode} source={args.source} limit={args.limit}")

    agents = make_agents(args.mode)
    files = discover_files(args.source)
    all_findings: dict[str, list[dict[str, Any]]] = {key: [] for key in files}

    for log_type, paths in files.items():
        if not paths:
            print(f"[{log_type}] no JSONL files found; skipping.")
            continue

        agent = agents[log_type]
        for path in paths:
            events = load_jsonl(path, args.limit)
            print(f"[{log_type}] {path.name}: loaded {len(events)} events")

            for index, event in enumerate(events, start=1):
                result = agent.run_one(event)
                all_findings[log_type].append(result)
                print(f"\n[{log_type} event {index}]\n")
                print(json.dumps(result, ensure_ascii=False, indent=2))

    if all_findings:
        print("\n=== CORRELATION ===")
        correlation = CorrelationAgent(mode=args.mode).run(all_findings)
        print(json.dumps(correlation, ensure_ascii=False, indent=2))
    else:
        correlation = {}

    out_dir = ROOT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "agent_results.json").write_text(
        json.dumps(all_findings, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (out_dir / "correlation.json").write_text(
        json.dumps(correlation, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"\nSaved outputs to: {out_dir}")


if __name__ == "__main__":
    main()
