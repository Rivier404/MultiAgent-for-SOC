# Agents

Mỗi Agent kế thừa `BaseSOCAgent` và chỉ khai báo:

- `name`
- `log_type`
- `system_prompt`

`BaseSOCAgent` xử lý RAG, Ollama, JSON normalization và mock mode.
