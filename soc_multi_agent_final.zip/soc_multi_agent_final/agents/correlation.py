from __future__ import annotations

import json
from typing import Any

from llm_client import LLMError, OllamaClient
from rag.engine import RAGEngine


CORRELATION_SYSTEM = """
You are the SOC Correlation Agent and act as the senior analyst coordinating four specialized agents:
ADAgent, EndpointAgent, NetworkAgent, and WebAgent.

You receive structured findings produced independently by the four domain agents.

Your task:
1. Determine whether findings may belong to the same incident.
2. Correlate only when there is supporting evidence such as timestamp, source/destination IP,
   host, account, process, port/protocol, or consistent behavior.
3. Build a concise timeline using only supplied timestamps and findings.
4. Separate direct evidence from inference.
5. Highlight contradictions or missing information.
6. Do not invent events, users, hosts, IP addresses, or successful attacks.
7. Do not treat the mere presence of a finding as proof of a single shared incident.
8. RAG context is supporting security knowledge, not direct incident evidence.
9. Keep reasoning concise; do not reveal private chain-of-thought.
10. Return JSON only.

Return exactly:
{
  "incident_detected": false,
  "severity": "LOW|MEDIUM|HIGH|CRITICAL",
  "confidence_score": 0.0,
  "related_agents": [],
  "timeline": [],
  "correlated_evidence": [],
  "attack_hypothesis": "",
  "missing_information": [],
  "recommended_actions": []
}
"""


class CorrelationAgent:
    name = "CorrelationAgent"

    def __init__(
        self,
        llm: OllamaClient | None = None,
        rag: RAGEngine | None = None,
        mode: str = "ollama",
    ) -> None:
        self.llm = llm or OllamaClient()
        self.rag = rag or RAGEngine()
        self.mode = mode

    def run(self, findings: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
        if self.mode == "mock":
            return self.mock_result(findings)

        compact = json.dumps(findings, ensure_ascii=False, indent=2)
        rag_hits = self.rag.search("correlation", compact, k=4)
        rag_context = "\n\n".join(
            f"[{hit.id}] score={hit.score}\n{hit.description}"
            for hit in rag_hits
        ) or "(no RAG context retrieved)"

        user = (
            "AGENT FINDINGS:\n"
            + compact
            + "\n\nRAG CONTEXT:\n"
            + rag_context
        )

        try:
            result = self.llm.chat_json(CORRELATION_SYSTEM, user)
        except LLMError as exc:
            return {
                "incident_detected": False,
                "severity": "LOW",
                "confidence_score": 0.0,
                "related_agents": [],
                "timeline": [],
                "correlated_evidence": [f"Correlation LLM error: {exc}"],
                "attack_hypothesis": "",
                "missing_information": ["LLM correlation unavailable"],
                "recommended_actions": [
                    "Retry correlation after checking Ollama."
                ],
            }

        return self.normalize_result(result)

    @staticmethod
    def normalize_result(result: dict[str, Any]) -> dict[str, Any]:
        confidence = result.get("confidence_score", 0.0)
        try:
            confidence = min(1.0, max(0.0, float(confidence)))
        except (TypeError, ValueError):
            confidence = 0.0

        severity = str(result.get("severity", "LOW")).upper()
        if severity not in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}:
            severity = "LOW"

        related_agents = result.get("related_agents", [])
        if not isinstance(related_agents, list):
            related_agents = [str(related_agents)]

        timeline = result.get("timeline", [])
        if not isinstance(timeline, list):
            timeline = [timeline]

        evidence = result.get("correlated_evidence", [])
        if not isinstance(evidence, list):
            evidence = [evidence]

        missing = result.get("missing_information", [])
        if not isinstance(missing, list):
            missing = [missing]

        actions = result.get("recommended_actions", [])
        if not isinstance(actions, list):
            actions = [actions]

        return {
            "incident_detected": bool(result.get("incident_detected", False)),
            "severity": severity,
            "confidence_score": confidence,
            "related_agents": [str(x) for x in related_agents[:8]],
            "timeline": timeline[:12],
            "correlated_evidence": [str(x) for x in evidence[:12]],
            "attack_hypothesis": str(result.get("attack_hypothesis", "")),
            "missing_information": [str(x) for x in missing[:12]],
            "recommended_actions": [str(x) for x in actions[:12]],
        }

    @staticmethod
    def mock_result(findings: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
        agents = []
        evidence: list[str] = []
        suspicious_agents = []

        for agent, values in findings.items():
            if not values:
                continue
            agents.append(agent)
            first = values[0]
            evidence.extend(first.get("reasoning_steps", [])[:2])
            verdict = str(first.get("verdict", "")).lower()
            threat = str(first.get("threat_level", "LOW")).upper()
            if verdict in {"suspicious", "malicious"} or threat in {"HIGH", "CRITICAL"}:
                suspicious_agents.append(agent)

        incident_detected = len(suspicious_agents) > 1

        return {
            "incident_detected": incident_detected,
            "severity": "MEDIUM" if incident_detected else "LOW",
            "confidence_score": 0.50 if incident_detected else 0.20,
            "related_agents": agents,
            "timeline": [],
            "correlated_evidence": evidence,
            "attack_hypothesis": (
                "Mock result only. Real correlation requires Ollama mode."
            ),
            "missing_information": [],
            "recommended_actions": [
                "Run the same test with --mode ollama."
            ],
        }
