from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from llm_client import LLMError, OllamaClient
from rag.engine import RAGEngine


class BaseSOCAgent:
    """Shared SOC-agent behavior: RAG context, LLM call, normalization, mock mode."""

    name = "BaseSOCAgent"
    log_type = "unknown"
    system_prompt = ""

    def __init__(
        self,
        llm: OllamaClient | None = None,
        rag: RAGEngine | None = None,
        mode: str = "ollama",
    ) -> None:
        self.llm = llm or OllamaClient()
        self.rag = rag or RAGEngine()
        self.mode = mode

    def build_rag_context(self, event: dict[str, Any]) -> str:
        query = " ".join(
            str(event.get(key, ""))
            for key in (
                "event_code",
                "event_type",
                "description",
                "uri",
                "raw_log",
                "process",
                "command",
                "protocol",
                "dest_port",
                "source_ip",
                "dest_ip",
                "username",
                "user",
            )
        ).strip()

        hits = self.rag.search(self.log_type, query, k=3)
        if not hits:
            return "(no RAG context retrieved)"

        return "\n\n".join(
            f"[{hit.id}] score={hit.score}\n{hit.description}"
            for hit in hits
        )

    def run_one(self, event: dict[str, Any]) -> dict[str, Any]:
        event_id = str(event.get("event_id") or event.get("id") or "UNKNOWN")

        if self.mode == "mock":
            return self.mock_result(event)

        rag_context = self.build_rag_context(event)
        user = (
            "INPUT EVENT:\n"
            + json.dumps(event, ensure_ascii=False, indent=2)
            + "\n\nRAG CONTEXT:\n"
            + rag_context
        )

        try:
            result = self.llm.chat_json(self.system_prompt, user)
        except LLMError as exc:
            return self.error_result(event, f"LLM error: {exc}")

        return self.normalize_result(event, result)

    def normalize_result(
        self,
        event: dict[str, Any],
        result: dict[str, Any],
    ) -> dict[str, Any]:
        confidence = result.get("confidence_score", result.get("confidence", 0.0))
        try:
            confidence = float(confidence)
        except (TypeError, ValueError):
            confidence = 0.0
        confidence = min(1.0, max(0.0, confidence))

        verdict = str(result.get("verdict", "insufficient_evidence")).lower()
        allowed_verdicts = {
            "benign",
            "suspicious",
            "malicious",
            "insufficient_evidence",
        }
        if verdict not in allowed_verdicts:
            verdict = "insufficient_evidence"

        threat = str(result.get("threat_level", "LOW")).upper()
        if threat not in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}:
            threat = "LOW"

        reasoning = result.get("reasoning_steps", [])
        if not isinstance(reasoning, list):
            reasoning = [str(reasoning)]

        recommendations = result.get("recommended_actions", [])
        if not isinstance(recommendations, list):
            recommendations = [str(recommendations)]

        is_fp = result.get("is_false_positive", False)
        if not isinstance(is_fp, bool):
            is_fp = str(is_fp).strip().lower() == "true"

        return {
            "event_id": str(result.get("event_id") or event.get("event_id") or "UNKNOWN"),
            "agent_routed": self.name,
            "verdict": verdict,
            "is_false_positive": is_fp,
            "threat_level": threat,
            "confidence_score": confidence,
            "reasoning_steps": [str(x) for x in reasoning[:8]],
            "analysis_summary": str(result.get("analysis_summary", "")),
            "recommended_actions": [str(x) for x in recommendations[:8]],
        }

    def error_result(self, event: dict[str, Any], message: str) -> dict[str, Any]:
        return {
            "event_id": str(event.get("event_id") or event.get("id") or "UNKNOWN"),
            "agent_routed": self.name,
            "verdict": "insufficient_evidence",
            "is_false_positive": False,
            "threat_level": "LOW",
            "confidence_score": 0.0,
            "reasoning_steps": [message],
            "analysis_summary": "Agent could not complete analysis.",
            "recommended_actions": [
                "Retry the analysis after checking the LLM service."
            ],
        }

    def mock_result(self, event: dict[str, Any]) -> dict[str, Any]:
        """Deterministic result to validate the pipeline without invoking an LLM."""
        event_id = str(event.get("event_id") or event.get("id") or "UNKNOWN")
        source = str(event.get("source_ip") or "unknown")
        dest = str(event.get("dest_ip") or "unknown")

        if self.log_type == "ad":
            code = event.get("event_code") or event.get("event_id_windows")
            description = str(event.get("description", "")).lower()
            failed = str(code) == "4625" or "failed" in description
            return {
                "event_id": event_id,
                "agent_routed": self.name,
                "verdict": "suspicious" if failed else "benign",
                "is_false_positive": not failed,
                "threat_level": "HIGH" if failed else "LOW",
                "confidence_score": 0.94 if failed else 0.80,
                "reasoning_steps": [
                    "Windows Event ID 4625 indicates a failed logon attempt."
                    if failed
                    else "No explicit failed-logon indicator was found.",
                    f"Source IP observed: {source}.",
                    "A repeated authentication pattern requires correlation before declaring brute force."
                    if failed
                    else "The single authentication event does not provide strong evidence of malicious activity.",
                ],
                "analysis_summary": (
                    "Potential suspicious authentication activity."
                    if failed
                    else "No strong AD threat indicator in this event."
                ),
                "recommended_actions": (
                    [
                        "Review nearby failed and successful logons for the same account and source IP.",
                        "Correlate with endpoint and network telemetry.",
                    ]
                    if failed
                    else ["Continue monitoring related authentication events."]
                ),
            }

        if self.log_type == "endpoint":
            command = str(event.get("command", "")).lower()
            process = str(event.get("process", "")).lower()
            suspicious = any(token in command or token in process for token in ("powershell", "mimikatz", "rundll32", "wmic"))
            return {
                "event_id": event_id,
                "agent_routed": self.name,
                "verdict": "suspicious" if suspicious else "benign",
                "is_false_positive": not suspicious,
                "threat_level": "HIGH" if suspicious else "LOW",
                "confidence_score": 0.90 if suspicious else 0.80,
                "reasoning_steps": [
                    "Suspicious scripting or credential-access tooling is present."
                    if suspicious
                    else "No high-confidence suspicious process indicator was found.",
                    f"Process: {event.get('process', 'unknown')}.",
                ],
                "analysis_summary": (
                    "Potential suspicious endpoint execution."
                    if suspicious
                    else "No strong endpoint threat indicator in this event."
                ),
                "recommended_actions": (
                    [
                        "Review parent-child process relationships.",
                        "Collect surrounding endpoint telemetry.",
                    ]
                    if suspicious
                    else ["Continue monitoring endpoint activity."]
                ),
            }

        if self.log_type == "network":
            port = str(
                event.get("dest_port")
                or event.get("id.resp_p")
                or event.get("destination_port")
                or ""
            )
            protocol = str(
                event.get("protocol")
                or event.get("proto")
                or event.get("id.proto")
                or ""
            ).lower()
            suspicious = port in {"445", "3389"}
            return {
                "event_id": event_id,
                "agent_routed": self.name,
                "verdict": "suspicious" if suspicious else "benign",
                "is_false_positive": not suspicious,
                "threat_level": "MEDIUM" if suspicious else "LOW",
                "confidence_score": 0.78 if suspicious else 0.88,
                "reasoning_steps": [
                    f"Connection from {source} to {dest} observed.",
                    f"Destination port: {port or 'unknown'}; protocol: {protocol or 'unknown'}.",
                    "A single connection is insufficient to establish lateral movement or command-and-control."
                    if not suspicious
                    else "Destination port is commonly associated with an administrative service and requires correlation.",
                ],
                "analysis_summary": (
                    "Potential administrative-service network activity requiring correlation."
                    if suspicious
                    else "The single network event does not provide strong evidence of malicious behavior."
                ),
                "recommended_actions": [
                    "Correlate the source host with endpoint and AD telemetry."
                    if suspicious
                    else "Continue monitoring and correlate with adjacent network events."
                ],
            }

        if self.log_type == "web":
            raw = str(event.get("raw_log", "")).lower()
            uri = str(event.get("uri", "")).lower()
            suspicious_terms = ["_vti_", ".htaccess", "union", "select", "../", "shell", "<script"]
            suspicious = any(term in (raw + " " + uri) for term in suspicious_terms)
            return {
                "event_id": event_id,
                "agent_routed": self.name,
                "verdict": "suspicious" if suspicious else "benign",
                "is_false_positive": not suspicious,
                "threat_level": "MEDIUM" if suspicious else "LOW",
                "confidence_score": 0.86 if suspicious else 0.84,
                "reasoning_steps": [
                    f"HTTP request observed from {source} to {dest}.",
                    "Request targets a special or potentially sensitive web path."
                    if suspicious
                    else "No clearly suspicious URI pattern was found.",
                ],
                "analysis_summary": (
                    "Potential web reconnaissance or malicious request pattern."
                    if suspicious
                    else "No strong web threat indicator in this event."
                ),
                "recommended_actions": (
                    [
                        "Review adjacent HTTP requests by the same source IP.",
                        "Correlate with network and endpoint telemetry.",
                    ]
                    if suspicious
                    else ["Continue monitoring adjacent web requests."]
                ),
            }

        return self.error_result(event, "Unsupported log type for mock mode.")

    def load_events(self, path: str | Path, limit: int = 10) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        with Path(path).open("r", encoding="utf-8", errors="ignore") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    value = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(value, dict):
                    events.append(value)
                if len(events) >= limit:
                    break
        return events
