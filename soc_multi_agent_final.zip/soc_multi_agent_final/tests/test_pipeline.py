from agents import ADAgent, EndpointAgent, NetworkAgent, WebAgent, CorrelationAgent


def test_agent_output_contracts():
    event = {
        "event_id": "TEST-1",
        "source_ip": "10.0.0.1",
        "dest_ip": "10.0.0.2",
        "dest_port": 443,
        "protocol": "tcp",
        "raw_log": "GET /index.html",
    }

    for agent in [
        ADAgent(mode="mock"),
        EndpointAgent(mode="mock"),
        NetworkAgent(mode="mock"),
        WebAgent(mode="mock"),
    ]:
        result = agent.run_one(event)
        assert set(result) == {
            "event_id",
            "agent_routed",
            "verdict",
            "is_false_positive",
            "threat_level",
            "confidence_score",
            "reasoning_steps",
            "analysis_summary",
            "recommended_actions",
        }
        assert 0.0 <= result["confidence_score"] <= 1.0


def test_correlation_mock():
    findings = {
        "network": [
            {
                "verdict": "suspicious",
                "threat_level": "MEDIUM",
                "reasoning_steps": ["Network evidence"],
            }
        ],
        "web": [
            {
                "verdict": "malicious",
                "threat_level": "HIGH",
                "reasoning_steps": ["Web evidence"],
            }
        ],
        "ad": [],
        "endpoint": [],
    }

    result = CorrelationAgent(mode="mock").run(findings)
    assert result["incident_detected"] is True
    assert "network" in result["related_agents"]
    assert "web" in result["related_agents"]
