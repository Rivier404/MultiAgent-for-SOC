# Web SOC Knowledge

Unusual URI paths or repeated HTTP requests can indicate reconnaissance or endpoint enumeration,
but a suspicious request alone does not prove successful exploitation.

Examples of signals requiring correlation include path traversal sequences, SQL-like input,
script payload indicators, enumeration of sensitive paths, repeated probing, and suspicious
response patterns.

Web findings should be correlated with source IP, timestamps, network telemetry, and endpoint data.
