# Network SOC Knowledge

A normal TCP connection is not proof of malicious activity.

Common destination ports such as 80 (HTTP), 443 (HTTPS), 22 (SSH), 389 (LDAP), and 445 (SMB)
can be legitimate services. Port numbers should be interpreted together with timestamps,
connection patterns, asset role, authentication activity, and other telemetry.

A single established connection state is not enough to prove lateral movement or command-and-control.

Potential signals that justify further investigation include repeated unusual connections,
scanning patterns, unexpected administrative-service access, unusual source/destination relationships,
and corroborating endpoint or Active Directory activity.
