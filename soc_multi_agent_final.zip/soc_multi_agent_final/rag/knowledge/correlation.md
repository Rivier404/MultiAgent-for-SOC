# SOC Correlation Guidance

Correlate events using evidence such as timestamp proximity, source/destination IP, host, account,
process, port/protocol, and consistent behavior.

The presence of multiple findings is not automatically a single incident. Findings should be linked
only when there is a defensible relationship.

Direct log evidence should be separated from analyst inference and hypotheses.
