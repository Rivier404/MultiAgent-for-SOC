# Endpoint SOC Knowledge

PowerShell and scripting are legitimate administration mechanisms and are not inherently malicious.

Stronger endpoint indicators may include suspicious parent-child process chains, encoded or obfuscated
commands, credential-dumping behavior, LSASS access, unexpected administrative tooling, persistence,
and execution from unusual locations.

A single suspicious command does not prove compromise. Correlation with other endpoint, AD, or network
telemetry increases confidence.
