# Active Directory SOC Knowledge

Repeated authentication failures against the same account or many accounts can indicate brute force
or password spraying, but one failed authentication does not prove an attack.

Privileged-account activity, unusual authentication patterns, Kerberos anomalies, privilege changes,
and corroborating endpoint or network activity can increase confidence.

Account compromise should not be declared without supporting evidence such as successful authentication,
privilege change, suspicious process activity, or correlated lateral movement.
