from __future__ import annotations

import re
from pathlib import Path

from .models import RAGResult


class RAGEngine:
    """Lightweight local RAG for the beginner PoC.

    Reads Markdown knowledge files and ranks them by token overlap.
    No vector DB is required for the first experiment.
    """

    def __init__(self, root: str | Path | None = None) -> None:
        default_root = Path(__file__).resolve().parent / "knowledge"
        self.root = Path(root).resolve() if root else default_root
        self._docs: list[tuple[str, str, str]] = []
        self._load()

    def _load(self) -> None:
        self._docs.clear()
        if not self.root.exists():
            return
        for path in sorted(self.root.rglob("*.md")):
            text = path.read_text(encoding="utf-8", errors="ignore")
            self._docs.append((str(path.relative_to(self.root)), path.stem, text))

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return {x.lower() for x in re.findall(r"[A-Za-z0-9_.-]{3,}", text)}

    def search(self, collection: str, query: str, k: int = 5) -> list[RAGResult]:
        q = self._tokens(f"{collection} {query}")
        scored: list[RAGResult] = []

        for rel, name, text in self._docs:
            tokens = self._tokens(text)
            if not tokens:
                continue

            overlap = len(q & tokens)
            score = overlap / max(1, len(q))
            if score <= 0:
                continue

            scored.append(
                RAGResult(
                    id=rel,
                    name=name,
                    description=text[:1400].strip(),
                    score=round(score, 4),
                    metadata={
                        "source": rel,
                        "collection": collection,
                    },
                )
            )

        scored.sort(key=lambda item: item.score, reverse=True)
        return scored[:k]
