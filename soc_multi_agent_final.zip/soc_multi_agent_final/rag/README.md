# RAG

RAG phiên bản đầu là local lexical retrieval từ Markdown.

Knowledge files:

- `ad.md`
- `endpoint.md`
- `network.md`
- `web.md`
- `correlation.md`

Sau khi PoC ổn định có thể thay `RAGEngine.search()` bằng Chroma/Qdrant mà không cần đổi interface của các Agent.
